//
//  AudioVideoControllerViewController.h
//  iCare
//
//  Created by ido zamberg on 21/12/13.
//  Copyright (c) 2013 ido zamberg. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "AudioFile.h"
#import "FlowManager.h"
#import "Exercise.h"

@interface AudioVideoControllerViewController : UIViewController
{
	AVAudioPlayer *audioPlayer;
}

@property (weak, nonatomic) IBOutlet UIButton *btnPlayAudio;
@property (weak, nonatomic) IBOutlet UIButton *btnShowList;
@property (strong,nonatomic) AudioFile*        currentAudioFile;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblLevel;

- (IBAction)playClicked:(id)sender;
- (IBAction)showListClicked:(id)sender;
- (void) setAudioFile : (AudioFile*) file;



@end
