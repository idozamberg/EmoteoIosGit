//
//  FlowManager.m
//  iCare
//
//  Created by ido zamberg on 1/3/14.
//  Copyright (c) 2014 ido zamberg. All rights reserved.
//

#import "FlowManager.h"
#import "LevelViewController.h"

@implementation FlowManager

@synthesize storyBoard,navigationController;

static FlowManager* manager;

+ (FlowManager*) sharedInstance
{
    if (!manager)
    {
        manager = [FlowManager new];
        manager.storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        manager.navigationController = (UINavigationController*)[UIApplication sharedApplication].keyWindow.rootViewController;
    }
    
    return manager;
}

- (void) showExerciseListWithList : (NSArray*) list forLevel : (NSNumber*) level andType :(exerciseListType) type
{
    ExerciseListViewController* vcExercise = [storyBoard instantiateViewControllerWithIdentifier:@"vcExercise"];
    
    // Setting vc properties
    vcExercise.exerciseList = list;
    vcExercise.listType = type;
    [vcExercise setLevel:level];
    
    [navigationController pushViewController:vcExercise animated:YES];
}

- (void) showVideoViewControllerWithVideo : (VideoFile*) video
{
    // Go to next screen
    LevelViewController* vcLevel = [storyBoard instantiateViewControllerWithIdentifier:@"levelVC"];
    
    // Setting the video to load
    [vcLevel setVideo:video];
    
    [navigationController popToRootViewControllerAnimated:NO];
    
    [navigationController pushViewController:vcLevel animated:YES];

}

- (void) showAudioViewControllerWithAudioFile : (AudioFile*) file
{
    // Go to next screen
    AudioVideoControllerViewController* vcLevel = [storyBoard instantiateViewControllerWithIdentifier:@"audioVC"];
    
    [vcLevel setAudioFile:file];
    
    [navigationController popToRootViewControllerAnimated:NO];
    
    [navigationController pushViewController:vcLevel animated:YES];
}

- (void) showMenuVCWithType : (menuTableType) type
{
  //  MenuViewController
    
    MenuViewController* menuVC = [storyBoard instantiateViewControllerWithIdentifier:@"menuVC"];
    
    menuVC.tableType = type;
    
    [navigationController pushViewController:menuVC animated:YES];

}

- (void) showEmergencySettings
{
    EmergencyCallSettingsViewController* ecVC = [storyBoard instantiateViewControllerWithIdentifier:@"emergencySettingsVC"];
    
    [navigationController pushViewController:ecVC animated:YES];

}

- (void) showShakeVC
{
    EmergencyCallSettingsViewController* shakeVC = [storyBoard instantiateViewControllerWithIdentifier:@"shakeVC"];
    
    [navigationController pushViewController:shakeVC animated:YES];

}

@end
