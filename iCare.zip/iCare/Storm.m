//
//  Storm.m
//  iCare
//
//  Created by ido zamberg on 1/14/14.
//  Copyright (c) 2014 ido zamberg. All rights reserved.
//

#import "Storm.h"

@implementation Storm

- (id) init
{
    self = [super init];
    
    if (self)
    {
        self.exercises = [NSMutableArray new];
    }
    
    return self;
}

- (void) addExercise : (Exercise*) newExercise
{
    // Only add if does not exist
    if (![self.exercises containsObject:newExercise])
    {
        [self.exercises addObject:newExercise];
    }
}

@end
