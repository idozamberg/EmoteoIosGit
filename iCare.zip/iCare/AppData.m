//
//  AppData.m
//  iCare
//
//  Created by ido zamberg on 20/12/13.
//  Copyright (c) 2013 ido zamberg. All rights reserved.
//

#import "AppData.h"

@implementation AppData

static AppData* shareData;

@synthesize shouldEvaluateTension,videos,audioFiles;
@synthesize emergencyNumber = _emergencyNumber;
@synthesize shakeLevel = _shakeLevel;
@synthesize isInStorm;

+ (AppData*) sharedInstance
{
    if (!shareData)
   {
       shareData = [AppData new];
            
       shareData.shouldEvaluateTension = NO;
       shareData.videos = [NSMutableDictionary new];
       shareData.audioFiles = [NSMutableDictionary new];
       shareData.stormsHistory = [NSMutableArray new];
       shareData.isInStorm = NO;
   }
    
    return shareData;
}

- (NSArray*) getVideosForLevel : (NSNumber*) level
{
    return [videos objectForKey:level];
}

// This function will create a new storm and return it
- (Storm*) addNewStorm
{
    //  Adding new storm to array
    Storm* newStorm = [Storm new];
    [self.stormsHistory addObject:newStorm];
    
    return newStorm;
}

- (NSArray*) getAudiosForLevel : (NSNumber*) level
{
    return [audioFiles objectForKey:level];
}

- (void) setEmergencyNumber:(NSString *)emergencyNumber
{
    _emergencyNumber = emergencyNumber;
    
    [[NSUserDefaults standardUserDefaults] setObject:emergencyNumber forKey:@"emergency"];
}

- (void) setShakeLevel:(NSString *)shakeLevel
{
    _shakeLevel = shakeLevel;
    
    [[NSUserDefaults standardUserDefaults] setObject:shakeLevel forKey:@"level"];
}

- (Storm*)   currentStorm
{
    if (self.stormsHistory.count > 0)
    {
        return ([self.stormsHistory objectAtIndex:self.stormsHistory.count - 1]);
    }
    
    return Nil;
    
}

@end
