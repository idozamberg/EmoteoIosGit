//
//  UIHelper.m
//  iCare
//
//  Created by ido zamberg on 1/10/14.
//  Copyright (c) 2014 ido zamberg. All rights reserved.
//

#import "UIHelper.h"

@implementation UIHelper

+ (void) showMessage : (NSString*) message
{
    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Information" message:message delegate:Nil cancelButtonTitle:@"OK" otherButtonTitles:Nil];
    
    [alert show];
}

@end
