//
//  MediaFile.m
//  iCare
//
//  Created by ido zamberg on 1/3/14.
//  Copyright (c) 2014 ido zamberg. All rights reserved.
//

#import "MediaFile.h"

@implementation MediaFile

@end
