//
//  Globals.m
//  iCare
//
//  Created by ido zamberg on 1/4/14.
//  Copyright (c) 2014 ido zamberg. All rights reserved.
//

#import "Globals.h"

@implementation Globals

@end
