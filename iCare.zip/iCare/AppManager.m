//
//  AppManager.m
//  iCare
//
//  Created by ido zamberg on 1/3/14.
//  Copyright (c) 2014 ido zamberg. All rights reserved.
//

#import "AppManager.h"

@implementation AppManager

static AppManager* sharedManager;

+ (AppManager*) sharedInstance
{
    if (!sharedManager)
    {
        sharedManager = [AppManager new];
    }
    
    return sharedManager;
}

- (void) performStartupProcedures
{
    [self loadAllVideos];
    [self loadAllAudioFiles];
    [self loadUserDefaults];
}

- (void) loadUserDefaults
{
    NSString* emergencyNumber = [[NSUserDefaults standardUserDefaults] objectForKey:@"emergency"];
    
    // Checking if it exist (first install)
    if (!emergencyNumber)
    {
        emergencyNumber = @"112";
    }
    
    // Setting in-app number
    [[AppData sharedInstance] setEmergencyNumber:emergencyNumber];
    
    NSString* defaultLevel = [[NSUserDefaults standardUserDefaults] objectForKey:@"level"];
    
    // Checking if it exist (first install)
    if (!defaultLevel)
    {
        defaultLevel = @"8";
    }
    
    // Setting in-app number
    [[AppData sharedInstance] setShakeLevel:defaultLevel];
    
}

- (void) loadAllAudioFiles
{
    AppData* data = [AppData sharedInstance];
    
    NSNumber* level7 = [NSNumber numberWithInt:7];
    
    NSMutableArray* audios7 = [NSMutableArray new];

    AudioFile* audio1 = [AudioFile new];
    audio1.fileName = @"eau.wav";
    audio1.title = @"EXERCICE DE L’EAU FROIDE";
    audio1.level = [NSNumber numberWithInteger:7];
    
    AudioFile* audio2 = [AudioFile new];
    audio2.fileName = @"apaisante.wav";
    audio2.title = @"EXERCICE DE LA MUSIQUE APAISANTE";
    audio2.level = [NSNumber numberWithInteger:7];
    
    [audios7 addObject:audio1];
    [audios7 addObject:audio2];
    
    [data.audioFiles setObject:audios7 forKey:level7];
}

- (void) loadAllVideos
{
    AppData* data = [AppData sharedInstance];
    
    NSNumber* level8 = [NSNumber numberWithInt:8];
    
    NSMutableArray* videos8 = [NSMutableArray new];

    // Adding videos
    VideoFile* vdOne = [VideoFile new];
    vdOne.fileName = @"JZGB";
    vdOne.fileType = @"mov";
    vdOne.title = @"EXERCICE DE L’EAU FROIDE";
    vdOne.level = [NSNumber numberWithInt:8];

    VideoFile* vdTwo = [VideoFile new];
    vdTwo.fileName = @"Ciel";
    vdTwo.fileType = @"mov";
    vdTwo.title    = @"EXERCICE DU CIEL";
    vdTwo.level = [NSNumber numberWithInt:8];
    
    // Adding videos to array
    [videos8 addObject:vdOne];
    [videos8 addObject:vdTwo];
    
    // Adding array to dictionary
    [data.videos setObject:videos8 forKey:level8];
    
}

@end
