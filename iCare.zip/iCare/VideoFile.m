//
//  VideoFile.m
//  iCare
//
//  Created by ido zamberg on 1/3/14.
//  Copyright (c) 2014 ido zamberg. All rights reserved.
//

#import "VideoFile.h"

@implementation VideoFile

@synthesize level,fileName,title,fileType;

@end
