//
//  AppData.h
//  iCare
//
//  Created by ido zamberg on 20/12/13.
//  Copyright (c) 2013 ido zamberg. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIHelper.h"
#import "Storm.h"

@interface AppData : NSObject

+ (AppData*) sharedInstance;

- (NSArray*) getVideosForLevel : (NSNumber*) level;
- (NSArray*) getAudiosForLevel : (NSNumber*) level;
- (Storm*)   currentStorm;
- (Storm*) addNewStorm;

@property (nonatomic) BOOL shouldEvaluateTension;
@property (nonatomic,strong) NSMutableDictionary* videos;
@property (nonatomic,strong) NSMutableDictionary* audioFiles;
@property (nonatomic,strong) NSString* emergencyNumber;
@property (nonatomic,strong) NSString* shakeLevel;
@property (nonatomic,strong) NSMutableArray * stormsHistory;
@property (nonatomic)        BOOL             isInStorm;


@end
