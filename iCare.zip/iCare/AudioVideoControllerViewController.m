//
//  AudioVideoControllerViewController.m
//  iCare
//
//  Created by ido zamberg on 21/12/13.
//  Copyright (c) 2013 ido zamberg. All rights reserved.
//

#import "AudioVideoControllerViewController.h"
#import "AppData.h"

@interface AudioVideoControllerViewController ()

@end

@implementation AudioVideoControllerViewController

@synthesize currentAudioFile;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    

}

- (void) setAudioFile : (AudioFile*) file
{
    self.currentAudioFile = file;
    
    // Setting file
    NSURL *url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@",[[NSBundle mainBundle] resourcePath],file.fileName]];
	
	NSError *error;
	audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
	audioPlayer.numberOfLoops = -1;
    
    // Creating new exersice
    Exercise* newExercise = [Exercise new];
    
    newExercise.level = file.level;
    newExercise.practiceTime = [NSDate date];
    newExercise.name = file.title;
    newExercise.type = exerciseTypeAudio;
    
    // Adding new exercise
    [[[AppData sharedInstance] currentStorm] addExercise:newExercise];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) viewWillAppear:(BOOL)animated
{
    self.lblLevel.text = [currentAudioFile.level stringValue];
    self.lblTitle.text = currentAudioFile.title;
}

- (void) viewWillDisappear:(BOOL)animated
{
    [AppData sharedInstance].shouldEvaluateTension = YES;
}


- (IBAction)playClicked:(id)sender {
    
  if ([audioPlayer isPlaying])
  {
      [audioPlayer pause];
      [self.btnPlayAudio setBackgroundImage:[UIImage imageNamed:@"play_off.png"]  forState:UIControlStateNormal];
      [self.btnPlayAudio setBackgroundImage:[UIImage imageNamed:@"play_on.png"]  forState:UIControlStateHighlighted];

  }
  else
  {
      [self.btnPlayAudio setBackgroundImage:[UIImage imageNamed:@"pause_off.gif"]  forState:UIControlStateNormal];
      [self.btnPlayAudio setBackgroundImage:[UIImage imageNamed:@"pause_off.gif"]  forState:UIControlStateHighlighted];
      [audioPlayer play];
  }

}

- (IBAction)showListClicked:(id)sender {
    
    // Show exercise list
    [[FlowManager sharedInstance] showExerciseListWithList:[[AppData sharedInstance]getAudiosForLevel:currentAudioFile.level] forLevel:currentAudioFile.level andType:audioType];
}
@end
