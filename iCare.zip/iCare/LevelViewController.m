//
//  LevelViewController.m
//  iCare
//
//  Created by ido zamberg on 19/12/13.
//  Copyright (c) 2013 ido zamberg. All rights reserved.
//

#import "LevelViewController.h"
#import "ExerciseListViewController.h"
#import "FlowManager.h"


@interface LevelViewController ()
{
    UIActivityIndicatorView* indicator;
    MPMoviePlayerViewController *theMovie;
    BOOL isPlaying;
}

@end

@implementation LevelViewController

@synthesize currentVideo;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    isPlaying = NO;
}

- (void) setVideo : (VideoFile*) video
{
    self.currentVideo = video;
    
    // Load video
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *moviePath = [bundle pathForResource:currentVideo.fileName ofType:currentVideo.fileType];
    NSURL *movieURL = [NSURL fileURLWithPath:moviePath];
    theMovie = [[MPMoviePlayerViewController alloc] initWithContentURL:movieURL];
    theMovie.moviePlayer.scalingMode = MPMovieScalingModeAspectFill;
    theMovie.view.frame = self.view.frame;
    
    // Setting thumb image
    UIImage *thumbnail = [theMovie.moviePlayer thumbnailImageAtTime:140.0
                                                         timeOption:MPMovieTimeOptionNearestKeyFrame];
    [theMovie.moviePlayer stop];
    
    [self.imgThumb setImage:thumbnail];
    
    // Creating new exersice
    Exercise* newExercise = [Exercise new];
    
    newExercise.level = video.level;
    newExercise.practiceTime = [NSDate date];
    newExercise.name = video.title;
    newExercise.type = exerciseTypeVideo;
    
    // Adding new exercise
    [[[AppData sharedInstance] currentStorm] addExercise:newExercise];
}

- (IBAction)chooseClicked:(id)sender {

    // Show exercise list
    [[FlowManager sharedInstance] showExerciseListWithList:[[AppData sharedInstance] getVideosForLevel:currentVideo.level] forLevel:currentVideo.level andType:videoType];
}

- (void) viewWillAppear:(BOOL)animated
{
    [indicator stopAnimating];
    [indicator removeFromSuperview];
    self.imgPlay.hidden = NO;
    
    // Setting title
    self.lblTitle.text = currentVideo.title;
    
    // Exercise finished
    if (isPlaying)
    {
        // Going back to the first screen
        [AppData sharedInstance].shouldEvaluateTension = YES;
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)playClicked:(id)sender {
    
    indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    indicator.frame = self.imgPlay.frame;
    
    [self.view addSubview:indicator];
    self.imgPlay.hidden = YES;
    
    [indicator startAnimating];
    
    [self performSelector:@selector(playVideo:) withObject:@"JZGB" afterDelay:1];
}

- (void) playVideo : (NSString*) movieName
{
    isPlaying = YES;
    
    [self.navigationController presentMoviePlayerViewControllerAnimated:theMovie];
    
    [theMovie.moviePlayer play];
}
@end
